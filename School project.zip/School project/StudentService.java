package schoolDatabase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StudentService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Student> findAll() {
        return jdbcTemplate.query("SELECT studentID, studentName, grade, special FROM student",
                (rs, rowNum) -> new Student(rs.getLong("studentID"), rs.getString("studentName"), rs.getString("grade"), rs.getString("special")));
    }

    public void update(Student student) {
        jdbcTemplate.update("UPDATE student SET studentName=?, grade=?, special=? WHERE studentID=?",
                student.getStudentName(), student.getGrade(), student.getSpecial(), student.getStudentID());
    }
    public void add(Student student) {
        jdbcTemplate.update("INSERT INTO student" + " SET studentName=?, grade=?, special=?",
                student.getStudentName(), student.getGrade(), student.getSpecial());    
        }
       public void delete(Student student) {
        jdbcTemplate.update("DELETE FROM student " + "WHERE studentID=?",
        		student.getStudentID());    }


}
