package schoolDatabase;

public class Student {

    private Long studentID;

    private String studentName, grade, special;

    public Student(Long studentID, String studentName, String grade, String special) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.grade = grade;
        this.special =special;
    }

	public Long getStudentID() {
		return studentID;
	}

	public void setStudentID(Long studentID) {
		this.studentID = studentID;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getSpecial() {
		return special;
	}

	public void setSpecial(String special) {
		this.special = special;
	}

}