package schoolDatabase;

import com.vaadin.data.Binder;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@SpringUI
public class VaadinUI extends UI {

    @Autowired
    private StudentService service;

    private Student student;
    private Binder<Student> binder = new Binder<>(Student.class);
 
    private Grid<Student> grid = new Grid(Student.class);

    private TextField studentName = new TextField("Student Name");
    private TextField grade = new TextField("Grade");
    private TextField special = new TextField("Special");
    private Button save = new Button("Update", e -> saveStudent());
    private Button add = new Button("Add New", e -> addStudent());
    private Button delete = new Button("Delete", e -> deleteStudent());

    @Override
    protected void init(VaadinRequest request) {
        updateGrid();
        grid.setColumns("studentName", "grade","special");
        grid.addSelectionListener(e -> updateForm());

        binder.bindInstanceFields(this);

        VerticalLayout layout = new VerticalLayout(grid, studentName, grade,special, save , add, delete);
        setContent(layout);
        
    }

 

	private void updateGrid() {
        List<Student> student = service.findAll();
        grid.setItems(student);
        setFormVisible(false);
    }

    private void updateForm() {
        if (grid.asSingleSelect().isEmpty()) {
            setFormVisible(false);
        } else {
            student = grid.asSingleSelect().getValue();
            binder.setBean(student);
            setFormVisible(true);
        }
    }

    private void setFormVisible(boolean visible) {

        studentName.setVisible(visible);
        grade.setVisible(visible);
        special.setVisible(visible);
        save.setVisible(visible);
        delete.setVisible(visible);
        add.setVisible(visible);
    }

    private void saveStudent() {
        service.update(student);
        updateGrid();
    }
    private void addStudent() {
        service.add(student);
        updateGrid();
    }
    private void deleteStudent() {
        service.delete(student);
        updateGrid();
	}
}
